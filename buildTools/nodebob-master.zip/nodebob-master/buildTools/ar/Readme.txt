A command-line reference and other bits of assistance can be found in the Help
document accessible by going Help > Help Topics. If the menu bar is not visible
right-click on the toolbar and choose "Show Menu".

This is release 0.9.0 of Anolis Resourcer from http://anolis.codeplex.com
and http://anol.is from the same guy who brought you xpize 5 and Vize 2.

Check them out at http://www.xpize.net and http://www.vizeos.net

Feel free to redistribute Resourcer.exe, you don't need to include the change-
list or the readme file.

If you're running Windows XP or earlier you will need the .NET Framework 2.0
(or later) installed in order to run Resourcer. Windows Vista (and later)
already have the .NET Framework built-in.

Thanks!
-- 
-David